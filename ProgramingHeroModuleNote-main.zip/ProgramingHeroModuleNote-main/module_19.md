# Recap (Module 19.1)

-

# Function, Call Function and loops (Module 19.2)

- Function is a block of code that performs a specific task.
- Function starts with `function` keyword and then the name of the function.
- Function naming is same as variable naming.
- after function name a parenthesis is used to define the arguments.
- Function can have parameters inside the parenthesis.Parameters are the values that are passed to the function.
- Inside parenthesis, parameters are separated by commas.
- block of code is started with `{` and ended with `}`.
- function call is made by using the function name followed by parenthesis.
- function call is used to execute the function.
- function call can be use in the project anytime you want to execute the function.

# Function with parameters & Return (Module 19.3)

- Function with parameters are used to pass values to the function.
- function return is used to return the value from the function.

12:54
