Var price = 33  //Need Semicolon to end the statement & Var and var are different javascript keywords are case sensitive.

var name - Shabana //can't use operator in variable name

var boxName = ‘Cocola; //can't use single quote in variable string value. String value should be warped with quotes.

var 88_price = 34; //can't use number in variable name

var enum = -1; //can't use future reserved word in variable name

var _$box’78 = ‘Monika’;  //can't use quote character in variable name

var home-address = “kochu khet”; //can't use special character (- hyphen)in variable name