////// ******* 1. function to create multiplication table of 13 ******* /////

function multiplicationTable(number) {
  for (var i = 1; i <= 10; i++) {
    console.log(number + "x" + i + " = " + number * i);
  }
}
multiplicationTable(8);

///// ******* 2. function to convert all case to lower Case ******* /////

/*
function convertToLower(name) {
  let myName = name.toLowerCase();
  return myName;
}

console.log(convertToLower("MaKsUd"));
console.log(convertToLower("Jodu"));
console.log(convertToLower("MODU"));
console.log(convertToLower("kODu"));
*/

///// ******* 3. Creating a function using fullName which take two parameters firstName and lastName ******* /////
/*
function fullName(firstName, lastName) {
  return firstName + " " + lastName;
}
console.log(fullName("Maksudur", "Rahman"));
console.log(fullName("Hablu", "Kanto"));
*/
///// ******* 4. function to find square of a number ******* /////

/*

function square(number) {
  return number * number;
}
console.log(square(2));

*/

///// ******* 5. Create  a Object pizza to store the pizza details and print out pepperoni (Extra) ******* /////

/*
var pizza = {
  toppings: ["cheese", "sauce", "pepperoni"],
  crust: "deep dish",
  serves: 2,
};

console.log(pizza.toppings[2]);
*/
