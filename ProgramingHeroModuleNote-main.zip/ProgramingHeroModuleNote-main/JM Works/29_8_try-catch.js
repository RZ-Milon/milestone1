const name = "ami";
// name = "tmi"
// console.log(name);
try{
name = "tmi";
}catch(error){
  console.log("getting error", error);

}
console.log(name)

