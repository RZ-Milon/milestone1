function startFan(){
  
}